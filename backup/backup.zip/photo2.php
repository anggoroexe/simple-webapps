<h1>gerbang logika and</h1>
<img src="img/and.jpg" >