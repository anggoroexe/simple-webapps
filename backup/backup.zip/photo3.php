<h1>gerbang logika or</h1>
<img src="img/or.jpg" >