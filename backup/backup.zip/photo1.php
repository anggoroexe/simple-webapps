<h1>gerbang logika not</h1>

<img src="img/not.png" >